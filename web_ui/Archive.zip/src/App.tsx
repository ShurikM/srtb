import LoginPage from "./components/LoginPage";

function App() {
  return <LoginPage />;
}

export default App;
